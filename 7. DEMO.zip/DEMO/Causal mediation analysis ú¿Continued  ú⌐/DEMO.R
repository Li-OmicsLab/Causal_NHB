#Causal mediation analysis#
#install.packages('mediation')#
#install.packages('Hmisc')#
library(Hmisc)
mydata=spss.get("D:/depression/DEMO.sav")
mydata$edu<-factor (mydata$edu)

mydata$diabetes <-factor (mydata$diabetes)
mydata$hyp <-factor (mydata$hyp)
mydata$heart <-factor (mydata$heart)
mydata$cancer <-factor (mydata$cancer)
mydata$stroke <-factor (mydata$stroke)

library(mediation)
medModel<-glm(drink~marry+age+sex+smoke+edu+bmi+hyp+heart+cancer+stroke,
              family=poisson(link = "log"),
              control=list(maxit=1000),
              data=mydata)
outModel<-glm(depression~marry*drink+age+sex+edu+smoke+bmi+hyp+heart+cancer+stroke,
              family=binomial(link = "probit"),
              control=list(maxit=1000),
              data=mydata)

library(mediation)
med<-mediate(model.m =medModel,model.y=outModel,treat = 'marry',
             mediator = 'drink',weights = weight, data=mydata)
summary(med)


