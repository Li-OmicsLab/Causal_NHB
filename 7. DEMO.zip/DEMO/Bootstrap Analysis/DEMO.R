#Bootstrap Analysis#
library(mediation)
library(Hmisc)
mydata=spss.get("D:/depression/DEMO.sav")
mydata$edu<-factor (mydata$edu)

mydata$diabetes <-factor (mydata$diabetes)
mydata$hyp <-factor (mydata$hyp)
mydata$heart <-factor (mydata$heart)
mydata$cancer <-factor (mydata$cancer)
mydata$stroke <-factor (mydata$stroke)
ACME <- data.frame(Estimate=rep(NA,100),
                   CI_lower=rep(NA,100),
                   CI_upper=rep(NA,100))
ADE <- data.frame(Estimate=rep(NA,100),
                  CI_lower=rep(NA,100),
                  CI_upper=rep(NA,100))
Prop <- data.frame(Estimate=rep(NA,100),
                   CI_lower=rep(NA,100),
                   CI_upper=rep(NA,100))
for(i in 1:100){#bootstrap resampling =80% of total samples#
  sample1=sample(nrow(mydata),8212,replace=F)
  data1=mydata[sample1,]
  #establishing a causal model between marriage and alcohol drinking#
  library(mediation)
  medModel<-glm(drink~marry+age+sex+smoke+edu+bmi+hyp+heart+cancer+stroke,
                family=binomial(link = "probit"),
                control=list(maxit=1000),
                data=data1)
  
  #establishing a causal model between marriage,alcohol drinking, and depressive symptoms#
  outModel<-glm(depression~marry*drink+age+sex+edu+smoke+bmi+hyp+heart+cancer+stroke,
                family=binomial(link = "probit"),
                control=list(maxit=1000),
                data=data1)
  
  med<-mediate(model.m =medModel,model.y=outModel,treat = 'marry',
               mediator = 'drink', weights = weight, data=data1)
  s <- summary(med)
  ACME[i,] <- c(s$d.avg,s$d.avg.ci)
  ADE[i,] <- c(s$z.avg,s$z.avg.ci)
  Prop[i,] <- c(s$n.avg,s$n.avg.ci)
}
write.csv(cbind.data.frame(ACME,ADE,Prop),file = "D:/depression/unmarried1.csv",
          row.names = F,quote = F)




#Bootstrap Analysis#
library(mediation)
library(Hmisc)
mydata=spss.get("D:/depression/DEMO.sav")
mydata$edu<-factor (mydata$edu)

mydata$diabetes <-factor (mydata$diabetes)
mydata$hyp <-factor (mydata$hyp)
mydata$heart <-factor (mydata$heart)
mydata$cancer <-factor (mydata$cancer)
mydata$stroke <-factor (mydata$stroke)
ACME <- data.frame(Estimate=rep(NA,100),
                   CI_lower=rep(NA,100),
                   CI_upper=rep(NA,100))
ADE <- data.frame(Estimate=rep(NA,100),
                  CI_lower=rep(NA,100),
                  CI_upper=rep(NA,100))
Prop <- data.frame(Estimate=rep(NA,100),
                   CI_lower=rep(NA,100),
                   CI_upper=rep(NA,100))
for(i in 1:100){#bootstrap resampling = 50% of total samples#
  sample1=sample(nrow(mydata),5132,replace=F)
  data1=mydata[sample1,]
  #establishing a causal model between marriage and alcohol drinking#
  library(mediation)
  medModel<-glm(drink~marry+age+sex+smoke+edu+bmi+hyp+heart+cancer+stroke,
                family=binomial(link = "probit"),
                control=list(maxit=1000),
                data=data1)
  
  #establishing a causal model between marriage,alcohol drinking, and depressive symptoms#
  outModel<-glm(depression~marry*drink+age+sex+edu+smoke+bmi+hyp+heart+cancer+stroke,
                family=binomial(link = "probit"),
                control=list(maxit=1000),
                data=data1)
  
  med<-mediate(model.m =medModel,model.y=outModel,treat = 'marry',
               mediator = 'drink', weights = weight, data=data1)
  s <- summary(med)
  ACME[i,] <- c(s$d.avg,s$d.avg.ci)
  ADE[i,] <- c(s$z.avg,s$z.avg.ci)
  Prop[i,] <- c(s$n.avg,s$n.avg.ci)
}
write.csv(cbind.data.frame(ACME,ADE,Prop),file = "D:/depression/unmarried2.csv",
          row.names = F,quote = F)
